

import pandas as pd
import xlsxwriter


data1=pd.read_excel('Courier Company - Invoice.XLSX',index_col=0, header=0, usecols=[1,0,2,5,7])
data2=pd.DataFrame()
print(data1)
print(data2)
data1.insert(2, 'Total weight as per X (KG)',0 )
data1.insert(3, 'Weight slab as per X (KG)',0 )
data1.insert(5, 'Weight slab charged by Courier Company (KG)',0)
data1.insert(7, 'Delivery Zone charged by Courier Company',0)
data1.insert(8, 'Expected Charge as per X (Rs.)',0)
data1.insert(9, 'Charges Billed by Courier Company (Rs.) ',0)
data1.insert(10, 'Difference Between Expected Charges and Billed Charges (Rs.)',0)
data2.insert(0, '',0)
data2.insert(1, 'Count ',0)
data2.insert(1, 'Amount (Rs.)',0)





writer = pd.ExcelWriter('data005.xlsx', engine='openpyxl')


data1.to_excel(writer, sheet_name='Sheet1')
data2.to_excel(writer, sheet_name='Sheet2')


workbook = writer.book
worksheet = writer.sheets['Sheet1']
worksheet = writer.sheets['Sheet2']



for col in worksheet.columns:
    max_length = 0
    column = col[0].column_letter
    for cell in col:
        try:
            if len(str(cell.value)) > max_length:
                max_length = len(str(cell.value))
        except:
            pass
    adjusted_width = (max_length + 3) * 1.2
    worksheet.column_dimensions[column].width = adjusted_width


writer.close()





















